package com.ssafy.sms.model;

/**
 * sms도메인의 졸업생 클래스
 * -- DTO 패턴 기반
 * -- Encapsulation 적용
 * -- java.lang.Object#toString() : polymorphism(Overriding)
 * 
 * 1. 아이디		memberId	String
 * 2. 비밀번호	memberPw	String
 * 3. 이름		name		String
 * 4. 지역		location	String	광주, 구미, 서울, 대전, 부울경
 * 5. 소속반		classRoom	int		0<classRoom<30
 * 6. 입학일		entryDate	String	2023.07.05
 * 7. 기수		generation	int		0<generation<20
 * 8. 졸업여부	status		String	졸업, 재학, 중도퇴소
 * 9. 취업여부	isJob		boolean	true/false
 * 10.회사		company		String
 * 
 * 
 * @author SSAFY
 *
 */
public class Graduate extends Student {

}
