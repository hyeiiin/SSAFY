package com.ssafy.sms;

//교육생 Object를 만들 때, 사용하는 Class
/**
 *  Student 클래스 정의
 *  - 속성 : 변수
 *  1. 학생이름	name		String
 *  2. 소속지역	location	String
 *  3. 소속반		classRoom	int
 *  
 *  - 기능 : 메소드
 *  1. 자기소개	info()		void
 *  	- 범용적인 자기소개 : 이름, 소속지역, 반을 소개한다.
 * 	2. 학생을 만났을 자기소개 info(int num) 	void
 * 		- 같은반 : 이름 소개, 다른 반 : 범용적인 자기소개	
 * @author SSAFY
 *
 */
public class Student {
	static String team = "SSAFY";// 클래스 멤버 변수
//	String name = "김싸피"; //인스턴스 멤버 변수
//	String location = "광주";
//	int classRoom = 4;
	
	static void staticMethod() {
		System.out.println("Student");
	}
	
	private String name;
	private String location;
	private int classRoom;
	
	
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public int getClassRoom() {
		return classRoom;
	}

	public void setClassRoom(int classRoom) {
		this.classRoom = classRoom;
	}

	public void info() {
		System.out.println("저는 "+ name+ "입니다."
	+location+"에 "+classRoom+"반이예요");
	}
	
	public void info(int classRoom) {//지역 변수 - 파라미터 변수
		int num = 4; //지역변수
		if(classRoom == 4) {
		System.out.println("나랑 같은반? 나는"+name+"이야!");
		}else {
			info();
		}
	}
	/**
	 * 생성자의 특진
	 * 1. 클래스 이름과 같은 이름을 가짐(대소문자까지)
	 * 2. 리턴 타입의 개념이 없음
	 * 3. 오버로딩이 가능(즉, 다중 정의 가능)
	 * 	- 매개변수의 개수나 타입이 달라야한다.
	 * 4. 클래스안에 생성자가 단 1개도 없는 경우 컴파일러에 의해 자동으로 기본생성자 추가!!!
	 * 	--> 클래스 안에 생성자 정의 된 경우, 기본 생성자 추가 X
	 * 5. 상속이 안된다.
	 * @param name
	 * @param location
	 * @param classRoom
	 */
	public Student(String name, String location, int classRoom) {
		this.name=name;
		this.location = location;
		this.classRoom = classRoom;
	}
	
	public Student(String name) {
		this(name, null, 0);
//		this.name = name;
	}
	public Student(String name, String location) {
//		this.name = name;
//		this.location = location;
		this(name, location, 0);
	}
//	public Student() {
//		
//	}
	

	/**
	 * String 객체 잠깐 보기.
	 * - String 객체는 변경이 불가능 하다! = 한번 생성하면, 내용을 바꿀 수 없음.
	 * why? 
	 * 	1. String Pool = String 타입 사용이 빈번하여 존재.
	 * 		  String 객체를 새로 생성하기 보다 값이 같은 String이면 재사용 할 수 있도록 구현
	 * 		  String이 변할 수 있으면, 같은 문자열을 참조하는 두개의 변수가 있을 때
	 * 		  다른 쪽에 의해서 바뀔 수 있음
	 *  2. 보안 = 메서드의 파라미터로 String을 많이 사용 ex)패스워드, 이름, 웹에서 네트워크 연결 정보 등등
	 *  	이때, String이 변할 수 있으면 메서드의 인자로 받은 값이 다른 내부 호출에 의해 바뀔 수 있음
	 *  3. 동기화 = 멀티 스레드 환경에서 String을 사용하는 경우 값이 바뀔 위험이 더 커진다.
	 *  등등 결국 전체적으로 성능 측면에서 불변이 유리하다고 판단하여 String은 불변(immutable)하게 설계
	 *  
	 *  
	 */
	@Override
	public String toString() {
//		return "Student [name=" + name + ", location=" + location + ", classRoom=" + classRoom + "]";
		StringBuilder sb = new StringBuilder();
		sb.append("Student [name=");
		sb.append(name);
		sb.append(", location=");
		sb.append(location);
		sb.append(", classRoom=");
		sb.append(classRoom);
		sb.append("]");
		return sb.toString();
	}

	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}
