package com.ssafy.sms;

public class StudentNotFoundException extends Exception {

	public StudentNotFoundException(String memberId) {
		super("찾는 학생" + memberId+"가 없습니다.");
	}
}
