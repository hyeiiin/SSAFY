package com.ssafy.sms.model;

/**
 * sms도메인의 학생 클래스
 * -- DTO 패턴 기반
 * -- Encapsulation 적용
 * -- java.lang.Object#toString() : polymorphism(Overriding)
 * 
 * 1. 아이디		memberId	String
 * 2. 비밀번호	memberPw	String
 * 3. 이름		name		String
 * 4. 지역		location	String	광주, 구미, 서울, 대전, 부울경
 * 5. 소속반		classRoom	int		0<classRoom<30
 * 6. 입학일		entryDate	String	2023.07.05
 * 7. 기수		generation	int		0<generation<20
 * 8. 졸업여부	status		String	졸업, 재학, 중도퇴소
 * 
 * 
 * @author SSAFY
 *
 */
public class Student {
	
	private String memberId;
	private String memberPw;
	private String name;
	private String location;
	private int classRoom;
	private String entryDate;
	private int generation;
	private String status;
	
	
	
	
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Student(String memberId, String memberPw, String name, String location, int classRoom, String entryDate,
			int generation) {
		super();
		this.memberId = memberId;
		this.memberPw = memberPw;
		this.name = name;
		this.location = location;
		this.classRoom = classRoom;
		this.entryDate = entryDate;
		this.generation = generation;
		this.status = "재학";
	}




	public String getMemberId() {
		return memberId;
	}
	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}
	public String getMemberPw() {
		return memberPw;
	}
	public void setMemberPw(String memberPw) {
		this.memberPw = memberPw;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public int getClassRoom() {
		return classRoom;
	}
	public void setClassRoom(int classRoom) {
		this.classRoom = classRoom;
	}
	public String getEntryDate() {
		return entryDate;
	}
	public void setEntryDate(String entryDate) {
		this.entryDate = entryDate;
	}
	public int getGeneration() {
		return generation;
	}
	public void setGeneration(int generation) {
		this.generation = generation;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "Student [memberId=" + memberId + ", memberPw=" + memberPw + ", name=" + name + ", location=" + location
				+ ", classRoom=" + classRoom + ", entryDate=" + entryDate + ", generation=" + generation + ", status="
				+ status + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((memberId == null) ? 0 : memberId.hashCode());
		result = prime * result + ((memberPw == null) ? 0 : memberPw.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Student other = (Student) obj;
		if (memberId == null) {
			if (other.memberId != null)
				return false;
		} else if (!memberId.equals(other.memberId))
			return false;
		if (memberPw == null) {
			if (other.memberPw != null)
				return false;
		} else if (!memberPw.equals(other.memberPw))
			return false;
		return true;
	}
	
	
	
	

}
