package com.ssafy.sms.view;

import java.text.ParseException;
import java.util.Arrays;

import com.ssafy.sms.StudentNotFoundException;
import com.ssafy.sms.model.Student;
import com.ssafy.sms.model.StudentService;

/**
 * controller 역할(사용자 요청 받기), view역할(console 출력)
 * 
 * @author SSAFY
 *
 */
public class StudentTest {
	//테스트를 위한 출력 메서드(중복 정의)
		/*
		 * 1. 문자열 받아서 출력하는 print
		 * 2. Student객체를 받아서 출력하는 print
		 * 3. Student[] 배열을 받아서 출력하는 print
		 */
		public static void print(String message) {
			System.out.println("\n-----"+message);
		}
		
		public static void print(Student dto) {
			System.out.println(dto);
		}
		
		public static void print(Student[] students) {
			for (Student dto : students) {
				System.out.println(dto);
			}
		}

	public static void main(String[] args) throws ParseException {
		// TODO Auto-generated method stub
		// 학생 객체 만들기
		Student st1 = new Student("ssafy1", "1234", "김하나", "광주", 4, "2023.07.05", 10);
		Student st2 = new Student("ssafy2", "1234", "김두나", "대전", 4, "2023.07.05", 10);
		Student st3 = new Student("ssafy3", "1234", "김세나", "부울경", 4, "2023.07.05", 10);
		Student st4 = new Student("ssafy4", "1234", "김사나", "서울", 10, "2023.01.05", 9);
		Student st5 = new Student("ssafy5", "1234", "김다나", "구미", 4, "2022.07.03", 8);

		/*
		 * 1. 교육생등록 2. 등록 된 학생수 확인하기 3. 전체 학생 정보 조회 4. 학생 정보 상세 조회
		 */
		// 다양한 요청 처리를 담당하는 Service 클래스의 등장
//		StudentService service = new StudentService();
		StudentService service = StudentService.getInstance();
		print("1. 교육생 등록--------------------");
		service.addStudent(st1);
		service.addStudent(st2);
		service.addStudent(st3);
		service.addStudent(st4);
		service.addStudent(st5);
		service.addStudent(st5);

		int count = service.getIndexCount();
		print("2.전체 학생 수  : " + count + "--------------");

		System.out.println("3.전체 학생 정보 조회------------------");
		Student[] students = service.getStudentList();
//		System.out.println(Arrays.toString(students)); //보기 불편
//		for (Student dto : students) {
//			System.out.println(dto);// null 출력 됨
//			if(dto != null) {
//				System.out.println(dto);
//			}
//		} // 화면상 표시에는 문제가 없음, 사실 요청을 처리하는 service단에서 null을 제외하고 주는게 맞음

		print(students);
		
		System.out.println("4.학생 정보 상세 조회------------------");
		// "ssafy1" 아이디를 가진 학생을 조회한다면??
		Student student;
		try {
			student = service.getStudent("ssafy10");
		} catch (StudentNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//해당 학생이 존재하지 않으면 exception 발생
//		if (student != null)
//			System.out.println(student);
//		else
//			System.out.println("[주의] 해당 회원의 정보는 존재하지 않습니다.");
		
		print(service.getStudentList());
	}
	
	

}
