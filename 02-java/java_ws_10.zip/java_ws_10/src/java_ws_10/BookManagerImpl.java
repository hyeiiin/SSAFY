package java_ws_10;

import java.util.ArrayList;
import java.util.List;

public class BookManagerImpl implements IBookManager {
	
	private BookManagerImpl() {
		
	}
	
	private static BookManagerImpl instance = new BookManagerImpl();

	public static BookManagerImpl getInstance() {
		return instance;
	}

	//배열, List, Map, Set
	private List<Book> list = new ArrayList<Book>();
	
	@Override
	public void add(Book book) {
		list.add(book);
	}

	@Override
	public void remove(String isbn) {
		// TODO Auto-generated method stub

	}

	@Override
	public Book[] getList() {
		Book[] result = new Book[list.size()];
		
		return list.toArray(result);
	}

	@Override
	public Book[] getBooks() {
		ArrayList<Book> temp = new ArrayList<>();
		for (Book book : list) {
			if(!(book instanceof Magazine)) {//매거진 타입이 아니면, temp 리스트에 book객체 담기
				temp.add(book);
			}
		}
		//반환 타입 맞추기 위해서 Book[]배열 만들기
		Book[] result = new Book[temp.size()];
		return temp.toArray(result);
	}

	@Override
	public Magazine[] getMagazines() {
		ArrayList<Book> temp = new ArrayList<>();
		for (Book book : list) {
			if(book instanceof Magazine) {//매거진 타입이 아니면, temp 리스트에 book객체 담기
				temp.add(book);
			}
		}
		//반환 타입 맞추기 위해서 Book[]배열 만들기
		Magazine[] result = new Magazine[temp.size()];
		return temp.toArray(result);
	}

	@Override
	public Book[] searchByTitle(String title) {
		ArrayList<Book> temp = new ArrayList<>();
		for (Book book : list) {
			if(book.getTitle().contains(title)) {
				temp.add(book);
			}
		}
		return temp.toArray(new Book[temp.size()]);
	}

	@Override
	public Book searchByIsbn(String isbn) {
		for (Book book : list) {
			if(book.getIsbn().equals(isbn)) return book;
		}
		return null;
	}

	@Override
	public int getTotalPrice() {
		int totalPrice = 0;
		for (Book book : list) {
			totalPrice += book.getPrice();
		}
		return totalPrice;
	}

	@Override
	public double getPriceAvg() {
		// TODO Auto-generated method stub
		return (double)getTotalPrice()/list.size();
	}

	@Override
	public void sell(String isbn, int quantity) throws IsbnNotFoundException{
//		Book book = searchByIsbn(isbn);//위에 메서드가 구현되어 있다면 활용하면 좋음.
		Book findBook = null;
		for (Book book : list) {
			if(book.getIsbn().equals(isbn)) {
				findBook = book;
				break;
			}
		}
		if(findBook==null) {
			throw new IsbnNotFoundException(isbn);
		}else { //null이 아니면 팔기
		//원래 수량보다, 팔려는 수량이 클 수 있음 
		//어떻게 할까? 1. exception 발생시킨다. 2. 그냥 뺀다. 3. console에 찍고 값은 셋팅 안한다 등등
		// 생각해보고 구현할 것
		findBook.setQuantity(findBook.getQuantity()-quantity);
		}
	}

	@Override
	public void buy(String isbn, int quantity) {
		// TODO Auto-generated method stub

	}

}
