package com.ssafy.sms;
//JVM은 entry point로 main메서드를 찾음
/**
 * OOP is A P.I.E
 * 1.abstraction(추상화) :현실의 객체를 추상화 해서 클래스를 구현
 * @author SSAFY
 *
 */
public class StudentTest {
	static int num =1;
	public static void main(String[] args) {
		Student student1 = new Student(); //멤버 변수일까요? 지역 변수 일까요? 지역변수
		student1.info();
		System.out.println(student1.name);
		System.out.println(Student.team);
		student1.info(4);
		
		//객체의 추상화를 제대로 해보자.
		Student student2 = new Student();
		student2.classRoom = 4;
		student2.name = "김삼성";
		student2.location = "광주";
		student2.info();
		
		//생성자를 통해서 초기화해보자
		Student student3 = new Student("김하나", "광주", 4);
		Student student4 = new Student("김두나");
		student4.info();
		
		
		//졸업한 학생의 등장...? 난 재학생만 정의 했는데...
		//졸업한 학생 객체를 만들기 위해서 클래스 다시 정의
		//생성자는 상속이 안되잖아????
		Graduate graduate1 = new Graduate("김세나", "광주",4, "졸업", 8);
		graduate1.info(5);
		
		System.out.println(student2);
		
		String s1 = "안녕?";
		String s2 = "안녕?";
		System.out.println(s1==s2); //문자열이 같아서 true가 나오나?
		String s3 = new String("안녕?");
		System.out.println(s1==s3); //주소값을 비교한거 맞음. new 하면 String 새로 생성 됨
		
		
	}

}
