package com.ssafy.sms;

/**
 *  Graduate 클래스 정의
 *  - 속성 : 변수
 *  1. 학생이름	name		String
 *  2. 소속지역	location	String
 *  3. 소속반		classRoom	int
 *  4. 상태		status		String
 *  5. 기수 		generation	int
 *  
 *  - 기능 : 메소드
 *  1. 자기소개	info()		void
 *  	- 범용적인 자기소개 : 이름, 소속지역, 반을 소개한다.(과거형)
 * 	2. 학생을 만났을 자기소개 info(int num) 	void
 * 		- 같은기수?? : 같은 기수 였다고 인사, 다른 기수 : 범용적인 자기소개	
 * @author SSAFY
 *
 */
public class Graduate extends Student{

	String status;
	int generation;
	
	//생성자는 상속이 안된다!! 다시 재정의 해줘야한다. 
	public Graduate(String name, String location, int classRoom,String status, int generation) {
//		this(name, location, classRoom);//우린 이런 생성자 없지 않아?
		super(name, location, classRoom);
		this.status = status;
		this.generation = generation;
//		this.name = name;
//		this.location = location;
//		this.classRoom = classRoom;
	};
	
	@Override
	public void info() {
		System.out.printf("안녕하세요.저는 %s입니다. %s %d반 이었어요. %s한 상태입니다. %n", name,location, classRoom, status );
	}
	
	public void info(int generation) {
		if(generation == this.generation) {
			System.out.println("오 같은기수!");
		}else {
			this.info();
		}
	}
	
	
}
