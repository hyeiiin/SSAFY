package com.ssafy.sms.model;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;

/**
 * -- 싱글톤 패턴 적용 : 외부에서 객체 생성 금지!!!!!
 * 1. 생성자를 private 처리
 * 2. 스스로 객체 생성 -> new 
 * 3. 외부에서 생성 된 객체를 가져다 쓸 수 있도록 getter 제공
 * 4. 외부에서 객체 생성 못하는 상황에서 getter를 호출해야 하므로 getter메소드 static
 * 5. getter가 메모리에 올라올 때, 객체도 생성되어 있어야하므로 객체 생성도 static
 * @author SSAFY
 *
 */
public class StudentService implements IStudentService{
	/**
	 * 회원자료저장구죠 : 배열, private
	 */
	private Student[] students;
	/**
	 * 등록한 회원 숫자 정보 및 등록할 회원의 배열 요소의 인덱스 정보를 담는 멤버 변수
	 */
	private int indexCount;

	/*
	 * 고민1. students 배열은 언제 어디서 초기화 해줘야 하나?
	 * 고민2. 단순히 학생을 배열에 넣기만 하면 괜찮나?
	 * 고민3. 이미 등록된 학생을 다시 등록하는 경우에는 어쩌지?
	 * 고민4. 등록된 인원수는 어떻게 알 수 있을까?
	 * 등등 여러가지 고민해보세요.
	 */
	private StudentService() {
		this(5);
	}
	private StudentService(int length) {
		students = new Student[length];
	}
	
	private static StudentService instance = new StudentService();
	
	public static StudentService getInstance() {
		return instance;
	}
	
	@Override
	public void addStudent(Student dto) {
		//학생등록 전에 배열 저장소의 크기를 확인
		//배열 요소를 모두 사용 했으면, 새로 더 큰 배열 요소 생성
		//기존 배열 요소들을 복사해서 가야함.
		if(students.length == indexCount) {
			System.out.println("[중요] 학생 자료 저장구조를 추가 확장합니다.");
			students=Arrays.copyOf(students, students.length*2);
			System.out.println("[알림] 회원 자료 저장 구조의 크기는 최대"+students.length+"입니다.");
		}

		//학생 등록 전에 배열에 같은 학생이 있는지 확인
//		int exist = -1;
//		for (int i = 0; i < indexCount; i++) {
//			if(students[i].equals(dto)) {
//				exist = i;
////				students[indexCount++]= dto;
//				
//				break;
//			}
//		}
//		if(exist == -1) {
		if(exist(dto.getMemberId())==-1) {
			students[indexCount++]= dto;
		}else{
			System.out.println("[오류] 동일한 아이디가 존재합니다.");
		}
//		System.out.println(Arrays.toString(students));
	}
	
	//동일한 학생이 있는지 확인하기 위한 메소드 
	//내 맘대로 추가한거라서 interface에 추가할 필요 없음
	public int exist(String memberId) {
		for (int i = 0; i < indexCount; i++) {
			if(students[i].getMemberId().equals(memberId)) {
				return i;
			}
		}
		return -1;
	}

	@Override
	public int getIndexCount() {
		// TODO Auto-generated method stub
		return indexCount;
	}

	@Override
	public Student[] getStudentList() throws ParseException {
		// TODO Auto-generated method stub
//		return students; //문제점 : 배열의 크기가 크기 때문에 등록되 않은 배열요소 null이 출력 됨
		Student[] currentStudents = new Student[indexCount];
		for (int i = 0; i < currentStudents.length; i++) {
			//졸업 했는데, 재학 중으로 확인되는 학생 졸업시키기.
			//입학한 날짜와 현재 날짜를 비교해서 365일이 지났으면 졸업생으로 바꿔줘야지...
			// 
			Date now = new Date();
			Date entryDate= new SimpleDateFormat("yyyy.MM.dd").parse(students[i].getEntryDate());
//			System.out.println(now);
			
			long diffDay = (now.getTime()-entryDate.getTime())/(1000*60*60*24);
//			System.out.println(diffDay);
			if(diffDay>365) {
				//졸업생으로 변경하기
				changeToGenerate(students[i]);
			}
			currentStudents[i] = students[i];
		}
		return currentStudents;
	}
	
	public void changeToGenerate(Student dto) {
		int index = exist(dto.getMemberId());
		if(index>=0) {
			students[index]= new Graduate(dto);
			System.out.println(dto.getName()+"학생은 졸업했습니다.");
		}else {
			System.out.println("변경할 교육생이 없습니다. 등록되었는지 확인해주세요.");
		}
	}
	
	/**
	 * arraycopy(복사할 obj, 시작 idx, 복사하려는 obj, 시작idx, 데이터의 길이)
	 * @see java.lang.System#arraycopy(Object, int, Object, int, int)
	 * @return
	 */
	public Student[] getStudentList1() {
		Student[] currentStudents = new Student[indexCount];
		System.arraycopy(students, 0, currentStudents, 0, indexCount);
		return currentStudents;
	}
	/**
	 * @see java.util.Arrays#copyOf(boolean[], int)
	 * @return
	 */
	public Student[] getStudentList2() {
//		Student[] currentStudents = Arrays.copyOf(students, indexCount);
//		return currentStudents;
		return Arrays.copyOf(students, indexCount);
	}

	@Override
	public Student getStudent(String memberId) {
		int num = exist(memberId);
		if(num>=0) {
			return students[num];
		}else {
			
			return null;
		}
	}

}
