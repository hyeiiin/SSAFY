package com.ssafy.sms.model;

import java.text.ParseException;

public interface IStudentService {
	/**
	 * 학생 등록
	 * @param dto 학생 객체 
	 */
	public void addStudent(Student dto);
	/**
	 * 등록 인원수 조회
	 * @return 등록인원수
	 */
	public int getIndexCount();
	/**
	 * 전체 학생정보 조회
	 * @return Student타입의 배열
	 * @throws ParseException 
	 */
	public Student[] getStudentList() throws ParseException;
	/**
	 * 회원 상세 조회
	 * @param memberId 아이디
	 * @return 회원객체 리턴, 미존재하면  null
	 */
	public Student getStudent(String memberId);
	
	

}
