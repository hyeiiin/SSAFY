package com.ssafy.sms;
//JVM은 entry point로 main메서드를 찾음
/**
 * OOP is A P.I.E
 * 1.abstraction(추상화) :현실의 객체를 추상화 해서 클래스를 구현
 * @author SSAFY
 *
 */
public class StudentTest {
	static int num =1;
	public static void main(String[] args) {
		Student student1 = new Student(); //멤버 변수일까요? 지역 변수 일까요? 지역변수
		student1.info();
		System.out.println(student1.getName());
		System.out.println(Student.team);
		student1.info(4);
		
		//객체의 추상화를 제대로 해보자.
		Student student2 = new Student();
		student2.setClassRoom(4);
//		student2.name = "김삼성";
//		student2.location = "광주";
		student2.info();
		
		//생성자를 통해서 초기화해보자
		Student student3 = new Student("김하나", "광주", 4);
		Student student4 = new Student("김두나");
		student4.info();
		
		
		//졸업한 학생의 등장...? 난 재학생만 정의 했는데...
		//졸업한 학생 객체를 만들기 위해서 클래스 다시 정의
		//생성자는 상속이 안되잖아????
		Graduate graduate1 = new Graduate("김세나", "광주",4, "졸업", 8);
		graduate1.info(5);
		
		System.out.println(student2);
		
		String s1 = "안녕?";
		String s2 = "안녕?";
		System.out.println(s1==s2); //문자열이 같아서 true가 나오나?
		String s3 = new String("안녕?");
		System.out.println(s1==s3); //주소값을 비교한거 맞음. new 하면 String 새로 생성 됨
		
		//1.Encapsulation
		//2.Singleton
		//3.Polymorphism
		
//		graduate1.status = "재학";
//		graduate1.info();
//		graduate1.status = "메롱";
//		graduate1.info();
		//직접적 접근 안되도록 변경해야 겠다 ==> private
		//getter, setter 활용해서 셋팅
		graduate1.setStatus("메롱");
		graduate1.info();
		String test = new String("재학");
//		graduate1.setStatus("재학"); //==비교 했을 때 같은 값으로 나옴
		graduate1.setStatus(test);
		graduate1.info();
		
		
		//이제 클래스를 많이 만들었으니까, 학생 객체들을 만들어 볼까?
		Student st1 = new Student("김하나", "광주", 4);
		Student st2 = new Student("김두나", "광주", 4);
		Student st3 = new Student("김세나", "광주", 4);
		Student st4 = new Student("김사나", "광주", 4);
		
		Graduate gr1 = new Graduate("박하나","광주",4,"졸업",8);
		Graduate gr2 = new Graduate("박두나","광주",4,"졸업",8);
		Graduate gr3 = new Graduate("박세나","광주",4,"졸업",8);
		Graduate gr4 = new Graduate("박사나","광주",4,"졸업",8);
		
		
		Object[] objArr = {st1,st2,st3,st4,gr1,gr2,gr3,gr4};
		
		for (int i = 0; i < objArr.length; i++) {
//			(Student)objArr[i].info(); //Object에선 info()메소드가 안보여서...형변환 시도
			Student temp =(Student)objArr[i];
			temp.info();
		}
		
		//Object는 너무 범용적이니까, 비즈니스 로직상 최상위 객체 사용 권장.
		Student[] arr = {st1,st2,st3,st4,gr1,gr2,gr3,gr4};
		for (int i = 0; i < arr.length; i++) {
			arr[i].info();
		}
		System.out.println("-------------------");
		//졸업생만 자기소개 시켜보자.
		for (int i = 0; i < arr.length; i++) {
			if(arr[i] instanceof Graduate) {
				arr[i].info();
//				arr[i].company();//Student데이터 타입은 존재를 알 수 없다.
				Graduate temp = (Graduate)arr[i];
				temp.company();
			}
		}
		
		/*
		 * 정적 바인딩 vs 동적 바인딩
		 * 메소드 정적 바인딩 : 컴파일 타임에 실행 될 메소드가 바인딩(결정) 되는 것
		 * 메소드 동적 바인딩: 실행 시간(runtime)에 실행 메소드가 바인딩(결정) 되는 것
		 */
		
		st1.info();
		arr[4].info();
		
		Student.staticMethod();
		Graduate.staticMethod();
		
		//너무 정신이 없어서 리팩토링을 진행 할게요
		//객체 --> DTO 패턴 베이스
		// DTO(Data Transfer Object) vs VO(Value Object)???
		/*
		 * VO : 값 자체를 표현하는게 목적. --> 현재 애플리케이션의 비즈니스에 사용되는
		 * 의미가 담긴 값을 의미함.비즈니스 로직을 가질 수 있음. 
		 * 초기화 되면 값은 불변, read Only(getter만 존재).
		 * 두개의 VO의 속성(Property)값이 같으면 같은 것으로 판단.
		 * --> equals()/hashcode() overriding 필수
		 * 
		 * DTO : 계층간 데이터 전달이 목적, setter/getter 로직이 존재해도 무관
		 * 데이터 전달에 필요한 것들만 구현되어 있으면 됨.
		 */
		
	}

}
