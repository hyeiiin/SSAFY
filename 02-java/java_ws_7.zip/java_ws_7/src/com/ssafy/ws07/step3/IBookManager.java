package com.ssafy.ws07.step3;
//step3. Interface에 구현해야하는 메소드 작성
//     - BookManager가 Implements!
public interface IBookManager {

	void add(Book book);
	void remove(String isbn);
	Book[] getList();//전체 도서 목록
	Book searchByIsbn(String isbn);
	Book[] searchByTitle(String title);
	Magazine[] getMagazines(); //잡지 목록
	Book[] getBooks(); //일반 도서 목록
	int getTotalPrice();
	double getPriceAvg();
}
