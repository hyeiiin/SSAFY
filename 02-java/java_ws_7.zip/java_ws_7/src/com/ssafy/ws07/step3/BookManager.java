package com.ssafy.ws07.step3;

import java.util.Arrays;

//step6. 나머진 메소드 내부 구현 완성하기.
public class BookManager implements IBookManager {
	private final int MAX_SIZE = 100;
	private Book[] books = new Book[MAX_SIZE];
	private int size;
	//step2-2. BookManager는 싱글톤으로 만들기----------------------
	//	1. 생성자 private
	private BookManager() {
		
	}
	//	2. 내부에서 객체 생성. private static
	private static BookManager instance = new BookManager();
	//	3. getter 만들기. public static
	public static IBookManager getInstance() {
		return instance;
	}
	//-------------------------싱글톤 끝------------------------
	//step2-1. BookManager에 메서드 하나 만들어서 test
	@Override
	public void add(Book book) {
		// TODO Auto-generated method stub
		if(size<MAX_SIZE) books[size++] = book;
	}
	@Override
	public void remove(String isbn) {
		//삭제할 도서를 찾고, 맨 뒤에 저장된 도서를 가져와서 덮어쓰기
		//그 후 맨 뒤의 도서를 null 처리
		for (int i = 0; i < size; i++) { //size : 도서의 개수
			if(books[i].getIsbn().equals(isbn)) {
				books[i]=books[--size];
				books[size]=null;
				break;
			}
		}
		
	}
	@Override
	public Book[] getList() {
		return Arrays.copyOfRange(books,0, size);
	}
	@Override
	public Book searchByIsbn(String isbn) {
		for (int i = 0; i < size; i++) {
			if(books[i].getIsbn().equals(isbn))return books[i];
		}
		return null;
	}
	@Override
	public Book[] searchByTitle(String title) {
		int cnt=0;
		for (int i = 0; i < size; i++) {
			if(books[i].getTitle().contains(title)) {
				cnt++;
			}
		}
		
		Book[] temp = new Book[cnt];
		int index=0;
		for (int i = 0; i < size; i++) {
			if(books[i].getTitle().contains(title)) {
				temp[index++]=books[i];
			}
		}
		return temp;
	}
	@Override
	public Magazine[] getMagazines() {
		int cnt=0;
		for (int i = 0; i < size; i++) {
			if(books[i] instanceof Magazine) {
				cnt++;
			}
		}
		
		Magazine[] temp = new Magazine[cnt];
		int index=0;
		for (int i = 0; i < size; i++) {
			if(books[i] instanceof Magazine) {
				temp[index++]=(Magazine)books[i];
			}
		}
		return temp;
	}
	@Override
	public Book[] getBooks() {
		int cnt=0;
		for (int i = 0; i < size; i++) {
			if(!(books[i] instanceof Magazine)) {
				cnt++;
			}
		}
		
		Book[] temp = new Book[cnt];
		int index=0;
		for (int i = 0; i < size; i++) {
			if(!(books[i] instanceof Magazine)) {
				temp[index++]=books[i];
			}
		}
		return temp;
	}
	@Override
	public int getTotalPrice() {
		int totalPrice = 0;
		for (int i = 0; i < size; i++) {
			totalPrice+=books[i].getPrice();
		}
		return totalPrice;
	}
	@Override
	public double getPriceAvg() {
		// TODO Auto-generated method stub
		return (double)getTotalPrice()/size;
	}
	
	
	
}
