package com.ssafy.ws07.step3;

public class BookTest {

	public static void main(String[] args) {
		//싱글톤 객체 가져와서 사용하기
		//다형성에 의해서 상위 타입을 받을 수 있음. 
		//interface도 상속 받아서 구현하는 것으로, 상위 타입이 될 수 있음
		IBookManager manager = BookManager.getInstance();
		
		//BookManager 객체를 이용해 도서 정보 추가
		manager.add(new Book("1234","Java Pro", "김하나", "jaen.kr", 15000,"Java 기본 문법"));
		manager.add(new Book("1235","Java Pro2", "김하나", "jaen.kr", 25000,"Java 응용"));
		manager.add(new Book("32456","분석설계", "홍길동", "jaen.kr", 30000,"sw 모델링"));
		
		manager.add(new Magazine("546787","월간 알고리즘", "소나무", "jaen.kr", 10000,"알고리즘 7월", 2023, 07));
		manager.add(new Magazine("546786","월간 알고리즘", "소나무", "jaen.kr", 10000,"알고리즘 6월", 2023, 06));
		System.out.println("******도서 전체 목록*******");
		for (Book book : manager.getList()) {
			System.out.println(book);
		}
		System.out.println("******일반 도서 목록*******");
		for (Book book: manager.getBooks()) {
			System.out.println(book);
		}
		System.out.println("******잡지 목록*******");
		for(Magazine magazine : manager.getMagazines()) {
			System.out.println(magazine);
		}
		System.out.println("******도서 제목 포함 검색 : Java *******");
		Book[] books = manager.searchByTitle("Java");
		for (Book book : books) {
			System.out.println(book);
		}
		System.out.println("********도서 ISBN 검색 : 1234*******");
		System.out.println(manager.searchByIsbn("1234"));
		
		System.out.println("도서 가격 총합 : "+manager.getTotalPrice());
		System.out.println("도서 가격 평균 : "+manager.getPriceAvg());
		
		System.out.println("*****도서 삭제 : 1234 *******");
		manager.remove("1234");
		for (Book book : manager.getList()) {
			System.out.println(book);
		}

	}

}
